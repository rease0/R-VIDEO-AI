export function AdBanner() {
  return (
    <div className="bg-gray-200 p-4 text-center">
      <p className="text-sm text-gray-600">
        Upgrade to remove ads and unlock more features!
      </p>
    </div>
  )
}

